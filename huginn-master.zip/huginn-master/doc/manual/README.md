# Manual Installation

- [Requirements](requirements.md) Software and hardware requirements to run the Huginn installation
- [Install](installation.md) Installation guide for Ubuntu/Debian
- [Update](update.md) Update an existing Huginn installation
- Deploy updates via [Capistrano](capistrano.md)
