class MigrateGrowlAgentToLiquid < ActiveRecord::Migration[5.1]
  def change
    # Agents::GrowlAgent is no more
  end
end
